# 管理者権限で再起動
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process pwsh -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ============================================================
#  フォーム
# ============================================================
$form = New-Object System.Windows.Forms.Form
$form.Text = "Hyper-V VM 作成ツール"
$form.Size = New-Object System.Drawing.Size(700, 580)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false

# ============================================================
#  入力フィールドを動的に並べるヘルパー
# ============================================================
$script:rowY = 15

function Add-LabeledControl($labelText, $control, $controlWidth = 440) {
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $labelText
    $lbl.Location = New-Object System.Drawing.Point(15, ($script:rowY + 4))
    $lbl.Width = 145
    $lbl.TextAlign = "MiddleRight"

    $control.Location = New-Object System.Drawing.Point(165, $script:rowY)
    $control.Width    = $controlWidth

    $form.Controls.Add($lbl)
    $form.Controls.Add($control)
    $script:rowY += 36
}

# ---- VM 名 ----
$txtVMName = New-Object System.Windows.Forms.TextBox
Add-LabeledControl "VM 名 :" $txtVMName

# ---- 親 VHDX パス (テキスト + 参照ボタン) ----
$pnlVHD = New-Object System.Windows.Forms.Panel
$pnlVHD.Height = 26

$txtVHDPath = New-Object System.Windows.Forms.TextBox
$txtVHDPath.Width = 360
$txtVHDPath.Location = New-Object System.Drawing.Point(0, 0)

$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = "参照..."
$btnBrowse.Width = 72
$btnBrowse.Height = 26
$btnBrowse.Location = New-Object System.Drawing.Point(365, 0)

$pnlVHD.Controls.AddRange(@($txtVHDPath, $btnBrowse))
Add-LabeledControl "親 VHDX パス :" $pnlVHD 440

# ---- ベースパス ----
$txtBasePath = New-Object System.Windows.Forms.TextBox
$txtBasePath.Text = "D:\Hyper-V"
Add-LabeledControl "ベースパス :" $txtBasePath

# ---- メモリ ----
$pnlMem = New-Object System.Windows.Forms.Panel
$pnlMem.Height = 26

$numMem = New-Object System.Windows.Forms.NumericUpDown
$numMem.Width = 80; $numMem.Minimum = 1; $numMem.Maximum = 128; $numMem.Value = 4
$numMem.Location = New-Object System.Drawing.Point(0, 0)

$lblGB = New-Object System.Windows.Forms.Label
$lblGB.Text = "GB"; $lblGB.Location = New-Object System.Drawing.Point(85, 4); $lblGB.AutoSize = $true

$pnlMem.Controls.AddRange(@($numMem, $lblGB))
Add-LabeledControl "メモリ :" $pnlMem 200

# ---- CPU 数 ----
$numCPU = New-Object System.Windows.Forms.NumericUpDown
$numCPU.Width = 80; $numCPU.Minimum = 1; $numCPU.Maximum = 32; $numCPU.Value = 2
Add-LabeledControl "CPU 数 :" $numCPU 80

# ---- 仮想スイッチ ----
$cboSwitch = New-Object System.Windows.Forms.ComboBox
$cboSwitch.DropDownStyle = "DropDownList"
try { Get-VMSwitch | ForEach-Object { $cboSwitch.Items.Add($_.Name) | Out-Null } } catch {}
if ($cboSwitch.Items.Contains("Default Switch")) { $cboSwitch.SelectedItem = "Default Switch" }
elseif ($cboSwitch.Items.Count -gt 0)           { $cboSwitch.SelectedIndex = 0 }
Add-LabeledControl "仮想スイッチ :" $cboSwitch

# ---- Admin パスワード ----
$txtPassword = New-Object System.Windows.Forms.TextBox
$txtPassword.Text = "TS12345!"
Add-LabeledControl "Admin パスワード :" $txtPassword

# ---- 区切り ----
$sep = New-Object System.Windows.Forms.Label
$sep.BorderStyle = "Fixed3D"
$sep.Location = New-Object System.Drawing.Point(10, $script:rowY)
$sep.Size = New-Object System.Drawing.Size(665, 2)
$form.Controls.Add($sep)
$script:rowY += 12

# ---- 作成ボタン ----
$btnCreate = New-Object System.Windows.Forms.Button
$btnCreate.Text = "VM を作成する"
$btnCreate.Location = New-Object System.Drawing.Point(245, $script:rowY)
$btnCreate.Size = New-Object System.Drawing.Size(200, 36)
$btnCreate.Font = New-Object System.Drawing.Font("Meiryo UI", 11, [System.Drawing.FontStyle]::Bold)
$btnCreate.BackColor = [System.Drawing.Color]::FromArgb(0, 120, 212)
$btnCreate.ForeColor = [System.Drawing.Color]::White
$btnCreate.FlatStyle = "Flat"
$form.Controls.Add($btnCreate)
$script:rowY += 46

# ---- ログエリア ----
$lblLog = New-Object System.Windows.Forms.Label
$lblLog.Text = "ログ出力 :"; $lblLog.Location = New-Object System.Drawing.Point(15, $script:rowY); $lblLog.AutoSize = $true
$form.Controls.Add($lblLog)
$script:rowY += 20

$rtbLog = New-Object System.Windows.Forms.RichTextBox
$rtbLog.Location = New-Object System.Drawing.Point(10, $script:rowY)
$rtbLog.Size = New-Object System.Drawing.Size(666, 150)
$rtbLog.ReadOnly = $true
$rtbLog.BackColor = [System.Drawing.Color]::FromArgb(25, 25, 25)
$rtbLog.ForeColor = [System.Drawing.Color]::White
$rtbLog.Font = New-Object System.Drawing.Font("Consolas", 9)
$rtbLog.ScrollBars = "Vertical"
$form.Controls.Add($rtbLog)

# ============================================================
#  ログ出力ヘルパー
# ============================================================
function Write-Log($msg, [System.Drawing.Color]$color = [System.Drawing.Color]::White) {
    $rtbLog.SelectionStart  = $rtbLog.TextLength
    $rtbLog.SelectionLength = 0
    $rtbLog.SelectionColor  = $color
    $rtbLog.AppendText("$msg`n")
    $rtbLog.ScrollToCaret()
    [System.Windows.Forms.Application]::DoEvents()
}

# ============================================================
#  参照ボタン
# ============================================================
$btnBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = "VHDX / VHD ファイル (*.vhdx;*.vhd)|*.vhdx;*.vhd"
    $dlg.InitialDirectory = $txtBasePath.Text
    if ($dlg.ShowDialog() -eq "OK") { $txtVHDPath.Text = $dlg.FileName }
})

# ============================================================
#  VM 作成処理
# ============================================================
$btnCreate.Add_Click({
    $VMName     = $txtVMName.Text.Trim()
    $ParentVHD  = $txtVHDPath.Text.Trim()
    $BasePath   = $txtBasePath.Text.TrimEnd('\')
    $MemBytes   = [long]$numMem.Value * 1GB
    $CPUCount   = [int]$numCPU.Value
    $SwitchName = $cboSwitch.SelectedItem
    $AdminPass  = $txtPassword.Text

    # --- バリデーション ---
    if (-not $VMName)              { [System.Windows.Forms.MessageBox]::Show("VM名を入力してください。");          return }
    if (-not (Test-Path $ParentVHD)) { [System.Windows.Forms.MessageBox]::Show("親VHDXが見つかりません。");       return }
    if (-not $SwitchName)          { [System.Windows.Forms.MessageBox]::Show("仮想スイッチを選択してください。"); return }
    if (Get-VM -Name $VMName -ErrorAction SilentlyContinue) {
        [System.Windows.Forms.MessageBox]::Show("VM '$VMName' は既に存在します。"); return
    }

    $btnCreate.Enabled = $false
    $rtbLog.Clear()

    $vmBase         = "$BasePath\$VMName"
    $answerDir      = "$vmBase\Unattend"
    $answerFile     = "$answerDir\Autounattend.xml"
    $diffVHD        = "$vmBase\$VMName-diff.vhdx"
    $TempHiveKey    = "TempSystemHive_$VMName"

    try {
        # 1. フォルダ作成
        Write-Log "📁 フォルダ作成: $answerDir" ([System.Drawing.Color]::Cyan)
        New-Item -Path $answerDir -ItemType Directory -Force | Out-Null

        # 2. 応答ファイル作成
        Write-Log "📄 応答ファイル作成..." ([System.Drawing.Color]::Cyan)
        $xml = @"
<?xml version="1.0" encoding="utf-8"?>
<unattend xmlns="urn:schemas-microsoft-com:unattend">
    <settings pass="oobeSystem">
        <component name="Microsoft-Windows-International-Core" processorArchitecture="amd64" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS" xmlns:wcm="http://schemas.microsoft.com/WMIConfig/2002/State" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
            <InputLocale>0411:E0010411</InputLocale>
            <SystemLocale>ja-JP</SystemLocale>
            <UILanguage>ja-JP</UILanguage>
            <UserLocale>ja-JP</UserLocale>
        </component>
        <component name="Microsoft-Windows-Shell-Setup" processorArchitecture="amd64" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS" xmlns:wcm="http://schemas.microsoft.com/WMIConfig/2002/State" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
            <OOBE><HideEULAPage>true</HideEULAPage></OOBE>
            <UserAccounts>
                <AdministratorPassword><Value>$AdminPass</Value></AdministratorPassword>
            </UserAccounts>
            <TimeZone>Tokyo Standard Time</TimeZone>
        </component>
    </settings>
    <settings pass="generalize">
        <component name="Microsoft-Windows-PnpSysprep" processorArchitecture="amd64" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS" xmlns:wcm="http://schemas.microsoft.com/WMIConfig/2002/State" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
            <DoNotCleanUpNonPresentDevices>true</DoNotCleanUpNonPresentDevices>
            <PersistAllDeviceInstalls>true</PersistAllDeviceInstalls>
        </component>
    </settings>
    <settings pass="specialize">
        <component name="Microsoft-Windows-Shell-Setup" processorArchitecture="amd64" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS" xmlns:wcm="http://schemas.microsoft.com/WMIConfig/2002/State" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
            <ComputerName>$VMName</ComputerName>
        </component>
    </settings>
</unattend>
"@
        $xml | Out-File -Encoding UTF8 -FilePath $answerFile
        Write-Log "   保存: $answerFile" ([System.Drawing.Color]::LightGreen)

        # 3. 差分ディスク作成
        Write-Log "💽 差分ディスク作成: $diffVHD" ([System.Drawing.Color]::Cyan)
        New-VHD -Path $diffVHD -ParentPath $ParentVHD -Differencing | Out-Null
        Write-Log "   完了" ([System.Drawing.Color]::LightGreen)

        # 4. VHD マウント → ドライブ Z: 割り当て
        Write-Log "🔌 VHD マウント中..." ([System.Drawing.Color]::Cyan)
        $disk      = Mount-VHD -Path $diffVHD -PassThru | Get-Disk
        $partition = $disk | Get-Partition | Sort-Object Size -Descending | Select-Object -First 1
        Set-Partition -DiskNumber $partition.DiskNumber -PartitionNumber $partition.PartitionNumber -NewDriveLetter Z
        Write-Log "   ドライブ Z: 割り当て完了" ([System.Drawing.Color]::LightGreen)

        # 5. 応答ファイルコピー
        Write-Log "📋 応答ファイルをゲスト OS へコピー..." ([System.Drawing.Color]::Cyan)
        Copy-Item -Path $answerFile -Destination "Z:\AutoUnattend.xml" -Force
        Write-Log "   完了" ([System.Drawing.Color]::LightGreen)

        # 6. レジストリ設定
        Write-Log "🔧 レジストリ (UnattendFile) 設定中..." ([System.Drawing.Color]::Cyan)
        reg load "HKLM\$TempHiveKey" "Z:\Windows\System32\config\SYSTEM" | Out-Null
        $regPath = "HKLM:\$TempHiveKey\Setup"
        if (-not (Test-Path $regPath)) { New-Item -Path $regPath -Force | Out-Null }
        Set-ItemProperty -Path $regPath -Name "UnattendFile" -Value "C:\autounattend.xml" -Type String
        reg unload "HKLM\$TempHiveKey" | Out-Null
        Write-Log "   完了" ([System.Drawing.Color]::LightGreen)

        # 7. アンマウント
        Write-Log "📦 VHD アンマウント中..." ([System.Drawing.Color]::Cyan)
        Dismount-VHD -Path $diffVHD
        Write-Log "   完了" ([System.Drawing.Color]::LightGreen)

        # 8. VM 作成
        Write-Log "🖥  VM 作成中: $VMName  (メモリ $($numMem.Value)GB / CPU $CPUCount コア)" ([System.Drawing.Color]::Cyan)
        New-VM -Name $VMName -MemoryStartupBytes $MemBytes -BootDevice VHD `
               -VHDPath $diffVHD -Generation 2 -Path $vmBase -SwitchName $SwitchName | Out-Null
        Set-VMProcessor -VMName $VMName -Count $CPUCount
        Write-Log "   完了" ([System.Drawing.Color]::LightGreen)

        # 9. VM 起動
        Write-Log "🚀 VM 起動中..." ([System.Drawing.Color]::Cyan)
        Start-VM -Name $VMName
        Write-Log "`n✅ VM '$VMName' を作成・起動しました！" ([System.Drawing.Color]::LightGreen)

        [System.Windows.Forms.MessageBox]::Show(
            "VM '$VMName' の作成と起動が完了しました。", "完了",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information)

    } catch {
        Write-Log "`n❌ エラー: $_" ([System.Drawing.Color]::Red)
        # クリーンアップ
        try { Dismount-VHD -Path $diffVHD -ErrorAction SilentlyContinue } catch {}
        try { reg unload "HKLM\$TempHiveKey" 2>$null } catch {}
    } finally {
        $btnCreate.Enabled = $true
    }
})

[void]$form.ShowDialog()
